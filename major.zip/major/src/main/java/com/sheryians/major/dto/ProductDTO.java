package com.sheryians.major.dto;

import lombok.Data;

@Data
public class ProductDTO {
    private int id; //Here long is given
    private  String name;
    private Integer categoryId;
    private Double price;
    private Double weight;
    private String description;
    private String imageName;

}
